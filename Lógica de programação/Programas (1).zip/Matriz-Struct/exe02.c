/*#include <stdio.h>

int main ()
{
	char nomes [5][100];

	int i;
	for (i=0;i<5;i++){
        printf ("\nDigite um nome: ");
        scanf("%s", nomes[i]);
	}

	printf ("\n\n\nOs nomes que voce digitou foram:\n\n");
	for (i=0;i<5;i++){
        printf ("%s\n", nomes[i]);
	}

    return 0;
}
*/
