#include <stdio.h>

int main(){

    int linhas = 0, colunas = 0;

    printf("Informe o numero de linhas da matriz de notas:");
    scanf("%d", &linhas);

    printf("Informe o numero de colunas da matriz de notas:");
    scanf("%d", &colunas);

    printf("\n\n");

    float notas[linhas][colunas];

    int i, j;

    for (i=0; i<linhas; i++ ){
        for ( j=0; j<colunas; j++ ){
            printf("Informe a nota na posicao [%d][%d]:",i,j);
            scanf ("%f", &notas[i][j]);
        }
    }

    for (i=0; i<linhas; i++ ){
        for ( j=0; j<colunas; j++ ){
            printf("Nota[%d][%d]: %.2f",i,j,notas[i][j]);
            printf("\t");
        }
        printf("\n");
    }

    return 0;
}
