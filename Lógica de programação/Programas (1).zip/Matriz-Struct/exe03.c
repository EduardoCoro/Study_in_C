/*#include <stdio.h>

void flush_in(){
	int ch;
	while( (ch = fgetc(stdin)) != EOF && ch != '\n' ){}
}

int main ()
{
	char nomes [5][100];

	int i;
	for (i=0;i<5;i++){
        printf ("\nDigite um nome com espaco: ");
        scanf("%[^\n]s", nomes[i]); //Leitura dos caracteres digitados pelo usu�rio, at� o caracter ENTER [^\n].
        flush_in();
	}

	printf ("\n\n\nOs nomes que voce digitou foram:\n\n");
	for (i=0;i<5;i++){
        printf ("%s\n", nomes[i]);
	}

    return 0;
}
*/
