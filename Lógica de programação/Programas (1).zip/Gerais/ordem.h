void trocar (int *, int *);

void trocar (int *a, int *b){
    int aux = *b;
    *b = *a;
    *a = aux;
}

