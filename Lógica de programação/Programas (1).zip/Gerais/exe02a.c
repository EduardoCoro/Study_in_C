/*#include <stdio.h>
int main(){

	int movimento = 0;

	printf("\n");
	printf("-------------------------------------------------\n");
	printf("--- Bem vindo ao jogo defesa (1) / ataque (2) ---\n");
	printf("-------------------------------------------------\n");
	printf("\n");

	printf("Informe qual o movimento você deseja realizar: ");
	scanf("%d", &movimento);

	if (movimento == 1){
		printf("Defesa.");
	}else if(movimento == 2){
		printf("Ataque.");
	}else{
		printf("Número inválido.");
	}

	printf("\n\n");

	return 0;
}
*/
