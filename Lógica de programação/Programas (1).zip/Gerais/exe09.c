/*include <stdio.h>
int main(){

	int dia = 0;
	int mes = 0;
	int ano = 0;

	printf("\n");
	printf("-----------------------------------------\n");
	printf("--- Bem vindo ao programa aniversário ---\n");
	printf("-----------------------------------------\n");
	printf("\n");

	printf("Informe alguns dados sobre sua data de aniversário por favor...\n");
	printf("Dia: ");
	scanf("%d", &dia);
	if (dia > 0 && dia < 32){
		printf("Mês: ");
		scanf("%d", &mes);
		if (mes > 0 && mes < 13){
			printf("Ano: ");
			scanf("%d", &ano);
			if (ano < 2017){
					printf("Data de aniversário informada: %d/%d/%d\n", dia, mes, ano);
			}else{
				printf("Valor inválido. Digite um ano inferior a 2017.");
			}
		}else{
			printf("Valor inválido. Digite meses entre 1 e 12.");
		}
	}else{
		printf("Valor inválido. Digite dias entre 1 e 31.");
	}

	printf("\n\n");

	return 0;
}
*/
