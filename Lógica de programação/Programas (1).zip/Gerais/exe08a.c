/*#include <stdio.h>
int main(){

	int a = 0;
	int b = 0;
	int c = 0;

	printf("\n");
	printf("-------------------------------------------------------\n");
	printf("--- Bem vindo ao programa ordem crescente 3 números ---\n");
	printf("-------------------------------------------------------\n");
	printf("\n");

	printf("Informe o primeiro número: ");
	scanf("%d", &a);
	printf("Informe o segundo número : ");
	scanf("%d", &b);
	printf("Informe o terceiro número: ");
	scanf("%d", &c);

	printf("Números em ordem crescente: ");

	if (c > a)
    {
        if (a > b)
        {
            printf("%d - %d - %d", b, a, c);
        }
        else if (b < c)
        {
            printf("%d - %d - %d", a, b, c);
        }
    }
    else if (a > b)
    {
        if (b > c)
        {
            printf("%d - %d - %d", c, b, a);
        }
        else if (c < a)
        {
            printf("%d - %d - %d", b, c, a);
        }
    }
    else if (a < b)
    {
        if (c < a)
        {
            printf("%d - %d - %d", c, a, b);
        }
        else if (c < b)
        {
            printf("%d - %d - %d", a, c, b);
        }
    }

	printf("\n\n");

	return 0;
}
*/
