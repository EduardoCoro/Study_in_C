/*
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(){

	int opcaoJogador = 0;
	int valorJogador = 0;

	int resto = 0;

	srand(time(NULL)); //inicializar o gerador com a semente.
	int valorComputador = rand() % 10; //gerar número aleatório.


	printf("\n");
	printf("-----------------------------------------\n");
	printf("--- Bem vindo ao jogo do par ou ímpar ---\n");
	printf("-----------------------------------------\n");
	printf("\n");

	printf("Você quer par (0) ou ímpar (1): ");
	scanf("%d", &opcaoJogador);

	if (opcaoJogador == 0 || opcaoJogador == 1){
		printf("Informe um número inteiro: ");
		scanf("%d", &valorJogador);

		resto = (valorJogador + valorComputador) % 2;

		printf("Eu joguei %d e você %d.", valorComputador, valorJogador);

		if (opcaoJogador == 0 && resto == 0
			|| opcaoJogador == 1 && resto != 0){

			printf("Você ganhou!");
		}else{
			printf("Você perdeu!");
		}
	}else{
		printf("Opção inválida.");
	}

	printf("\n\n");

	return 0;
}
*/
