/*
#include <stdio.h>

int main(){

	printf("\n");
	printf("-----------------------------------------------\n");
	printf("--- Bem vindo ao programa Posto Combustível ---\n");
	printf("-----------------------------------------------\n");
	printf("\n");

	const float litrosDesconto = 20;
    const float menorDescontoAlcool = 0.02, maiorDescontoAlcool = 0.05;
    const float menorDescontoGasolina = 0.03, maiorDescontoGasolina = 0.06;
    const float precoLitroAlcool = 2, precoLitroGasolina = 3;

	int tipoCombustivel = 0;
	float litros = 0;
    float precoLitroComDesconto = 0;
    float valorAPagar = 0;

    printf("Qual combustível deseja abastecer (1-álcool, 2-gasolina): ");
    scanf("%d", &tipoCombustivel);

    printf("Quantos litros: ");
    scanf("%f", &litros);

    if (tipoCombustivel == 1)
    {
        if (litros > litrosDesconto)
        {
            precoLitroComDesconto = precoLitroAlcool * (1 - maiorDescontoAlcool);
        }
        else
        {
            precoLitroComDesconto = precoLitroAlcool * (1 - menorDescontoAlcool);
        }
    }
    else if (tipoCombustivel == 2)
    {

        if (litros > litrosDesconto)
        {
            precoLitroComDesconto = precoLitroGasolina * (1 - maiorDescontoGasolina);
        }
        else
        {
            precoLitroComDesconto = precoLitroGasolina * (1 - menorDescontoGasolina);
        }
    }
    else
    {
        printf("Tipo de combustível inválido!");
    }

    valorAPagar = precoLitroComDesconto * litros;

    printf("\nO valor a ser pago é: R$ %.2f", valorAPagar);

	printf("\n\n");

	return 0;
}
*/
