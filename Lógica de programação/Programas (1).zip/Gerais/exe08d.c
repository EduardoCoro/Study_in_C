/*
#include <stdio.h>
#include <ordem.h> //Nao se esqueca de configurar o code blocks. Menu Project > Build Options > Search Directories > Add

int main(){

	int a = 0, b = 0, c = 0, opcao = 0;

	printf("\n");
	printf("---------------------------------------------------------------------\n");
	printf("--- Bem vindo ao programa ordem crescente / decrescente 3 números ---\n");
	printf("---------------------------------------------------------------------\n");
	printf("\n");

	printf("Informe o primeiro número: ");
	scanf("%d", &a);
	printf("Informe o segundo número : ");
	scanf("%d", &b);
	printf("Informe o terceiro número: ");
	scanf("%d", &c);

	printf("\n1 - Crescente / 2 = Decrescente: ");
	scanf("%d", &opcao);

	if (!(a == b && b == c)){
        if (a > b){
            trocar(&a,&b); //passagem de parametro por referencia.
        }
        if (b > c){
            trocar(&b,&c); //passagem de parametro por referencia.
        }
        if (a > b){
            trocar(&a,&b); //passagem de parametro por referencia.
        }
	}

    if (opcao == 1){
        printf("Ordem crescente: %d - %d - %d", a, b, c);
    }else{
        printf("Ordem decrescente: %d - %d - %d", c, b, a);
    }

	printf("\n\n");

	return 0;
}
*/
