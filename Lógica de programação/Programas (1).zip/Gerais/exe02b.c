/*#include <stdio.h>
int main(){

	int movimento = 0;

	printf("\n");
	printf("-------------------------------------------------\n");
	printf("--- Bem vindo ao jogo defesa (1) / ataque (2) ---\n");
	printf("-------------------------------------------------\n");
	printf("\n");

	printf("Informe qual o movimento você deseja realizar: ");
	scanf("%d", &movimento);

	switch (movimento){
		case 1:
			printf("Defesa.");
			break;
		case 2:
			printf("Ataque.");
			break;
		default:
			printf("Número inválido.");
			break;
	}

	printf("\n\n");

	return 0;
}
*/
