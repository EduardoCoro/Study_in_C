/*#include <stdio.h>
int main(){

	const int senhaAcessoAoSistema = 78962653;
	int senha = 0;

	printf("\n");
	printf("-----------------------------------\n");
	printf("--- Bem vindo ao programa senha ---\n");
	printf("-----------------------------------\n");
	printf("\n");

	printf("Informe a senha para acessar o sistema: ");
	scanf("%d", &senha);

	if (senha == senhaAcessoAoSistema){
		printf("Acesso permitido!");
	}else{
		printf("Você não tem acesso ao sistema!");
	}

	printf("\n\n");

	return 0;
}
*/
