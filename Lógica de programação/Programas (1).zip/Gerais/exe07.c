/*#include <stdio.h>
int main(){

	int a = 0;
	int b = 0;

	printf("\n");
	printf("-----------------------------------------------\n");
	printf("--- Bem vindo ao programa ordem decrescente ---\n");
	printf("-----------------------------------------------\n");
	printf("\n");

	printf("Informe o primeiro número: ");
	scanf("%d", &a);
	printf("Informe o segundo número: ");
	scanf("%d", &b);

	printf("Números em ordem decrescente: ");

	if (a > b){
		printf("%d - %d", a, b);
	}else{
		printf("%d - %d", b, a);
	}

	printf("\n\n");

	return 0;
}
*/
