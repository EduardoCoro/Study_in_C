/*#include <stdio.h>
int main(){

	const int senhaAcessoAoSistema = 123456;
	const float saldoInicial = 1000;

	int senha = 0;
	float saldoAtual = saldoInicial;
	float valorSaque = 0;

	printf("\n");
	printf("--------------------------------------------\n");
	printf("--- Bem vindo ao programa saque de banco ---\n");
	printf("--------------------------------------------\n");
	printf("\n");

	printf("Informe a senha para acessar o sistema: ");
	scanf("%d", &senha);

	if (senha == senhaAcessoAoSistema){
		printf("Saldo atual da conta: %.2f \n", saldoAtual);

		printf("Informe o valor que deseja sacar: ");
		scanf("%f", &valorSaque);

		printf("\n");

		if (valorSaque > saldoAtual){
			printf("Seu saldo é insuficiente para realizar o saque!");
		}else{
			printf("Saque realizado com sucesso!\n");
			saldoAtual -= valorSaque;
			printf("Seu novo saldo é: %.2f", saldoAtual);
		}
	}else{
		printf("Senha inválida!");
	}

	printf("\n\n");

	return 0;
}
*/
