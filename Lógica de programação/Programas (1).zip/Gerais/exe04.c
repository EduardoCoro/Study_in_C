/*#include <stdio.h>
int main(){

	int diaSemana = 0;
	const char textoFinalSemana[21] = "Bom final de semana!";

	printf("\n");
	printf("-------------------------------------------\n");
	printf("--- Bem vindo ao programa dia da semana ---\n");
	printf("-------------------------------------------\n");
	printf("\n");

	printf("Informe o número referente ao dia da semana (1 a 7):");
	scanf("%d", &diaSemana);

	if (diaSemana > 0 && diaSemana < 8){

		if (diaSemana == 1){
			printf("Domingo. %s", textoFinalSemana);
		}else if (diaSemana == 2){
			printf("Segunda-Feira.");
		}else if (diaSemana == 3){
			printf("Terça-Feira.");
		}else if (diaSemana == 4){
			printf("Quarta-Feira.");
		}else if (diaSemana == 5){
			printf("Quinta-Feira.");
		}else if (diaSemana == 6){
			printf("Sexta-Feira.");
		}else{
			printf("Sábado. %s", textoFinalSemana);
		}
	}else{
		printf("Dia da semana inválido.");
	}

	printf("\n\n");

	return 0;
}
*/
