/*#include <stdio.h>
int main(){

	int a = 0;
	int b = 0;

	printf("\n");
	printf("---------------------------------------------\n");
	printf("--- Bem vindo ao programa ordem crescente ---\n");
	printf("---------------------------------------------\n");
	printf("\n");

	printf("Informe o primeiro número: ");
	scanf("%d", &a);
	printf("Informe o segundo número: ");
	scanf("%d", &b);

	printf("Números em ordem crescente: ");

	if (a > b){
		printf("%d - %d", b, a);
	}else{
		printf("%d - %d", a, b);
	}

	printf("\n\n");

	return 0;
}
*/
